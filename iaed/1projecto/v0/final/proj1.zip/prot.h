#ifndef PROJ_H
#define PROJ_H 1

void adicionaVotos(int EM, int PPE, int num_votos);
void deputadosEleitosEM(int EM);
void deputadosEleitosUE();
void inicializaPPE();
void metodo(int EM);

#endif
